<?php
$conn = mysqli_connect("localhost", "root", "", "pln_dashboard");
session_start();
?>
